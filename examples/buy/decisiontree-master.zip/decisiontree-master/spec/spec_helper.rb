require 'rspec/given'
require 'decisiontree'
require 'pry'

FIGURE_FILENAME = "just_a_spec"
