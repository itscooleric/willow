require 'core_extensions/object'
require 'core_extensions/array'
require File.dirname(__FILE__) + '/decisiontree/id3_tree.rb'
